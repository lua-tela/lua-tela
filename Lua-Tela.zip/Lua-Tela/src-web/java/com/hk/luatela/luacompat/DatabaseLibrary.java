package com.hk.luatela.luacompat;

import com.hk.func.BiConsumer;
import com.hk.lua.Environment;
import com.hk.lua.Lua;
import com.hk.lua.Lua.LuaMethod;
import com.hk.lua.LuaException;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaObject;
import com.hk.lua.LuaType;
import com.hk.luatela.db.LuaBase;
import com.hk.luatela.db.Instance;

public enum DatabaseLibrary implements BiConsumer<Environment, LuaObject>, LuaMethod
{
    model() {
        @Override
        public LuaObject call(LuaInterpreter interp, LuaObject[] args)
        {
            Lua.checkArgs(toString(), args, LuaType.STRING);
            return interp.getExtra("db", LuaBase.class).getModels().getModel(LuaBase.LUA, args[0].getString());
        }
    },
    save() {
        @Override
        public LuaObject call(LuaInterpreter interp, LuaObject[] args)
        {
            if(args.length >= 1 && args[0] instanceof Instance)
                return ((Instance) args[0]).save();
            else
                throw new LuaException("bad argument #1 to 'save' (expected INSTANCE*, got " + (args.length >= 1 ? args[0].name() : "nil") + ")");
        }
    };
//    total() {
//        @Override
//        public LuaObject call(LuaInterpreter interp, LuaObject[] args)
//        {
//            return Lua.newString(interp.getExtra("db", LuaBase.class).total);
//        }
//    };
    
    @Override
    public LuaObject call(LuaInterpreter interp, LuaObject[] args)
    {
        throw new Error();
    }
    
    @Override
    public void accept(Environment env, LuaObject table)
    {
        String name = toString();
        if(name != null && !name.trim().isEmpty())
            table.setIndex(env.interp, name, Lua.newFunc(this));
    }
}
