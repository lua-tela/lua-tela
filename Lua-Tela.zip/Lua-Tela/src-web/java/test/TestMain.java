package test;

import java.io.File;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
import com.hk.luatela.context.LuaAppContext;
import com.hk.luatela.db.LuaBaseImpl;
import main.routes.Routes.Route;

public class TestMain
{
    public static void main(String[] args)
    {
        String path = "index";
        String sessID = "123BOOB123";
        boolean loop = false;
        
        File run = new File(System.getProperty("user.dir"), "run");
        Scanner in = new Scanner(System.in);
        do
        {
            LuaAppContext ctx = new LuaAppContext(run, "https://thekayani.com", path, sessID);
            ctx.setDataSource("jdbc:mysql://localhost:3306/testdb?useSSL=false&allowPublicKeyRetrieval=true", "root", "hkrocks1");

            LuaBaseImpl base = new LuaBaseImpl(ctx, new File(run, "base"));

            try
            {
                Route route = base.routes.findRoute(ctx.path);

                if(route != null)
                {
                    ctx.setStatus(200);
                    route.serve(base, ctx, "get", ctx.url, ctx.path);
                }
            }
            catch (Exception ex)
            {
                Logger.getLogger(TestMain.class.getName()).log(Level.SEVERE, null, ex);
            }

            System.out.println(ctx.url + ctx.path + " (" + ctx.status + ") [" + ctx.contentType + "]");
            if(ctx.redirectURL != null)
                System.out.println("redirect to " + ctx.redirectURL);
            else
                System.out.println(ctx.toString());
            
            path = loop ? in.nextLine() : null;
            
            base.close();
        } while(path != null && !path.isEmpty());

        in.close();
    }
}