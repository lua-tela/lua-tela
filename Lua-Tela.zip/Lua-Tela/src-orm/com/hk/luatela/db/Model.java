package com.hk.luatela.db;

import com.hk.json.JsonObject;
import com.hk.json.JsonValue;
import com.hk.luatela.db.fields.IDField;
import com.hk.luatela.db.fields.DataField;
import com.hk.lua.Lua;
import com.hk.lua.LuaException;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaObject;
import com.hk.lua.LuaType;
import com.hk.lua.LuaUserdata;
import com.hk.luatela.db.fields.Fields;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

public class Model extends LuaUserdata
{
    public final LuaInterpreter interp;
    public final LuaBase db;
    public final int owner;
    public final String name, tblName;
    public final List<DataField> fields;
    private final Map<String, DataField> fieldNames;
    private LuaObject insMetatable;
    
    Model(LuaInterpreter interp, LuaBase db, int owner, String name, JsonObject obj)
    {
        this.interp = interp;
        this.db = db;
        this.owner = owner;
        this.name = name;
        tblName = LuaBase.toString(owner) + '_' + name;
        fieldNames = new HashMap<>();
        fields = new LinkedList<>();
        
        for(Map.Entry<String, JsonValue> ent : obj)
        {
            JsonValue val = ent.getValue();
            
            if(val.isObject())
            {
                JsonObject o = val.getObject();
                
                String nme = o.getString("field");
                Fields fieldType = Fields.byName(nme);
                
                if(fieldType == null)
                    throw new UnsupportedOperationException("Unknown field type '" + nme + "'");
                
                DataField field = fieldType.create(ent.getKey());
                field.importFromJson(o);
                
                fieldNames.put(ent.getKey(), field);
                fields.add(field);
                
            }
            else
                throw new UnsupportedOperationException("JSON model contains field that isn't an object?");
        }
        Collections.sort(fields, (DataField o1, DataField o2) -> Boolean.compare(o2.isPrimary(), o1.isPrimary()));
        
        if(interp != null)
            setupMetatables();
    }
        
    Model(LuaInterpreter interp, int owner, String name, LuaObject table)
    {
        this.interp = interp;
        this.db = interp.getExtra("db", LuaBase.class);
        this.owner = owner;
        this.name = name;
        tblName = LuaBase.toString(owner) + '_' + name;
        fieldNames = new HashMap<>();
        this.fields = new LinkedList<>();
        boolean primary = false;

        for(Map.Entry<LuaObject, LuaObject> ent : table.getEntries())
        {
            LuaObject key = ent.getKey();
            LuaObject val = ent.getValue();
            
            if(key.isString() && val instanceof DataField)
            {
                ((DataField) val).name = key.getString();
                primary = primary || ((DataField) val).isPrimary();
                fieldNames.put(key.getString(), (DataField) val);
                fields.add((DataField) val);
            }
            else
                throw new LuaException("unexpected entry in table, (" + key.getString() + "=" + val.getString() + ")");
        }

        if(primary)
            Collections.sort(fields, (DataField o1, DataField o2) -> Boolean.compare(o2.isPrimary(), o1.isPrimary()));
        else
        {
            int amt = 0;
            String nm = "id";
            while(fieldNames.containsKey(nm))
            {
                amt++;
                nm = "id" + amt;
            }
            IDField field = new IDField(interp, Lua.nil());
            field.name = nm;
            fieldNames.put(nm, field);
            fields.add(0, field.setPrimary());
        }
        
        setupMetatables();
    }
    
    private void setupMetatables()
    {
        insMetatable = Lua.newTable();
        LuaObject modelMetatable = Lua.newTable();
        modelMetatable.setIndex(interp, "__name", Lua.newString(name()));
        modelMetatable.setIndex(interp, "__index", modelMetatable);
        modelMetatable.setIndex(interp, "create", Lua.newFunc(this::create));
        modelMetatable.setIndex(interp, "get", Lua.newFunc(this::get));
        modelMetatable.setIndex(interp, "select", Lua.newFunc(this::select));
        
        LuaObject flds = Lua.newTable();
        for(DataField field : fields)
            flds.setIndex(interp, field.name, field);

        modelMetatable.setIndex(interp, "fields", flds);
        modelMetatable.setIndex(interp, "meta", insMetatable);
        modelMetatable.setIndex(interp, "funcs", insMetatable);
        metatable = modelMetatable;
    }

    LuaObject getInstanceMetatable()
    {
        return insMetatable;
    }
    
    public DataField getField(String field)
    {
        return fieldNames.get(field);
    }
    
    public void createTable()
    {
        StringBuilder sb = new StringBuilder();

        sb.append("CREATE TABLE IF NOT EXISTS `");
        sb.append(tblName);
        sb.append("` (\n");
        String[] primaries = new String[fields.size()];
        int i = 0;
        for(DataField field : fields)
        {
            sb.append('\t');

            if(field.isPrimary())
                primaries[i] = field.name;
            field.appendCreate(this, sb);

            sb.append(",\n");
            i++;
        }
        sb.append("\tPRIMARY KEY(");
        for(String primary : primaries)
        {
            if(primary == null)
                continue;
            sb.append('`');
            sb.append(primary);
            sb.append("`, ");
        }
        sb.setLength(sb.length() - 2);
        sb.append(")\n);");
        
        try
        {
            String sql = sb.toString();
//            db.total.append(sql).append("\n\n");
            db.update(sql);
        }
        catch (Exception ex)
        {
            throw new LuaException(ex.getLocalizedMessage());
//            throw new RuntimeException(ex);
        }
    }
    
    public void dropTable()
    {
        try
        {
            String sql = "DROP TABLE IF EXISTS `" + tblName + "`;";
//            db.total.append(sql).append("\n\n");
            db.update(sql);
        }
        catch (Exception ex)
        {
            throw new LuaException(ex.getLocalizedMessage());
//            throw new RuntimeException(ex);
        }
    }
    
    private LuaObject create(LuaInterpreter interp, LuaObject[] args)
    {
        Lua.checkArgs(getString() + " create", args, LuaType.TABLE);
        LuaObject tbl = args[0];
        try
        {
            Instance ins = new Instance(this, true);
            for(DataField field : fields)
                field.initiate(this, ins);
            
            for(Map.Entry<LuaObject, LuaObject> ent : tbl.getEntries())
            {
                if(ent.getKey().isString())
                {
                    DataField field = fieldNames.get(ent.getKey().getString());
                    ins.values.put(ent.getKey().getString(), field.clean(ent.getValue()));
                }
            }
            return ins;
        }
        catch (Exception ex)
        {
            throw new LuaException(ex.getLocalizedMessage());
        }
    }

    private LuaObject get(LuaInterpreter interp, LuaObject[] args)
    {
        Lua.checkArgs(getString() + " get", args, LuaType.TABLE);
        LuaObject tbl = args[0];
        
        Query query = new Query(interp, db, this);
        Query.where(interp, query, tbl);
        Query.open(interp, query);
        LuaObject obj = Query.next(interp, query);
        
        if(!Query.next(interp, query).isNil())
            throw new LuaException("more than one result, use select(...)");
        
        Query.close(interp, query);
        
        return obj;
    }
    
    private LuaObject select(LuaInterpreter interp, LuaObject[] args)
    {
        Query query = new Query(interp, db, this);
        if(args.length > 0)
        {
            LuaObject[] tmp = new LuaObject[args.length + 1];
            tmp[0] = query;
            System.arraycopy(args, 0, tmp, 1, args.length);
            query = Query.only(interp, tmp);
        }
        return query;
    }
    
    public Instance save(Instance ins)
    {
        if(ins.model != this)
            throw new IllegalArgumentException();
        
        StringBuilder sb = new StringBuilder();
        DataField autoField = null;
        PreparedStatement ps;
        
        try
        {
            if(ins.generated)
            {
                sb.append("INSERT INTO `").append(tblName).append("`(");
                for(DataField field : fields)
                {
                    if(field.isAuto())
                    {
                        autoField = field;
                        continue;
                    }

                    field.appendName(this, sb, false);
                    sb.append(", ");
                }
                sb.setLength(sb.length() - 2);
                sb.append(") VALUES (");
                for(DataField field : fields)
                {
                    if(field.isAuto())
                        continue;

    //                field.appendValue(this, sb, ins.values.get(field.name));
                    sb.append("?, ");
                }
                sb.setLength(sb.length() - 2);
                sb.append(");");
                ps = db.getConn().prepareStatement(sb.toString(), Statement.RETURN_GENERATED_KEYS);
                
                int indx = 1;
                for (DataField field : fields)
                {
                    if (field.isAuto())
                        continue;
                    
                    field.toJavaObject(ps, indx++, ins.values.get(field.name));
                }

                ins.generated = false;
            }
            else if(ins.changed)
            {            
                sb.append("UPDATE `").append(tblName).append("` SET ");

                DataField f;
                for(Map.Entry<String, LuaObject> e : ins.edited.entrySet())
                {
                    f = fieldNames.get(e.getKey());
                    f.appendName(this, sb, true);

                    sb.append(" = ?, ");
                }

                sb.setLength(sb.length() - 2);

                sb.append(" WHERE ");

                for(DataField field : fields)
                {
                    if(field.isPrimary())
                    {
                        field.appendName(this, sb, true);

                        sb.append(" = ? AND ");
//                        field.appendValue(this, sb, ins.values.get(field.name));
                    }
                }

                sb.setLength(sb.length() - 5);

                sb.append(";");
                ps = db.getConn().prepareStatement(sb.toString());
                
                int i = 1;
                for(Map.Entry<String, LuaObject> e : ins.edited.entrySet())
                    fieldNames.get(e.getKey()).toJavaObject(ps, i++, e.getValue());
                
                LuaObject val;
                for(DataField field : fields)
                {
                    if(field.isPrimary())
                    {
                        val = ins.values.get(field.name);
                        if(val == null)
                            throw new LuaException("expected primary key '" + name + '.' + field.name + "' to be present to update");

                        field.toJavaObject(ps, i++, val);
                    }
                }

                ins.changed = false;
                ins.values.putAll(ins.edited);
                ins.edited.clear();
            }
            else
                ps = null;
        
            if(ps != null)
            {
                String sql = sb.toString();
//                db.total.append(sql).append("\n\n");
                ps.executeUpdate();
                if(autoField != null)
                {
                    ResultSet set = ps.getGeneratedKeys();
                    if(set.next())
                        ins.values.put(autoField.name, Lua.newNumber(set.getLong(1)));

                    set.close();
                }
                ps.close();
            }
        }
        catch (SQLException | LuaException ex)
        {
            throw new LuaException(ex.getLocalizedMessage());
//            throw new RuntimeException(ex);
        }
        return ins;
    }
    
    @Override
    public final String name()
    {
        return "MODEL*";
    }

    @Override
    public Object getUserdata()
    {
        return this;
    }

    @Override
    public String getString(LuaInterpreter interp)
    {
        return "model '" + name + "'";
    }
    
    @Override
    public LuaObject doCall(LuaInterpreter interp, LuaObject[] args)
    {
        return create(interp, args);
    }
}
