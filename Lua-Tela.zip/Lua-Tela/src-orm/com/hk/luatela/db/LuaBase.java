package com.hk.luatela.db;

import java.io.Closeable;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public interface LuaBase extends Closeable
{    
    public File getBase();
    
    public Connection getConn();
    
    public boolean loaded();
    
    public PreparedStatement prepared(String toString) throws SQLException;

    public Statement statement() throws SQLException;

    public int update(String sql) throws SQLException;
    
    public Models getModels();
    
    public static String toString(int owner)
    {
        switch(owner)
        {
            case LUA: return "lua";
            case SYS: return "sys";
            default: throw new IllegalArgumentException("only expected LuaBase.USR or LuaBase.SYS, not " + owner + ".");
        }
    }
    
    public static final int LUA = 1;
    public static final int SYS = 2;
}