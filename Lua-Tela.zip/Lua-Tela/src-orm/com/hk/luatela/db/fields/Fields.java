package com.hk.luatela.db.fields;

import com.hk.func.BiFunction;
import com.hk.func.Function;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaObject;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

public enum Fields
{
    INTEGER(IntegerField::new, IntegerField::new, "integer", "int", "long"),
    FLOAT(FloatField::new, FloatField::new, "float", "double", "dec"),
    STRING(StringField::new, StringField::new, "string", "str"),
    BOOLEAN(BooleanField::new, BooleanField::new, "boolean", "bool"),
    TIMESTAMP(TimestampField::new, TimestampField::new, "timestamp"),
    // DATE(...),
    // TIME(...),
    // DATETIME(...),
    ID(IDField::new, IDField::new, "id");
    
    public final Function<String, DataField> factory;
    public final BiFunction<LuaInterpreter, LuaObject, DataField> supplier;
    public final Set<String> names;
    
    private Fields(Function<String, DataField> factory, BiFunction<LuaInterpreter, LuaObject, DataField> supplier, String... names)
    {
        this.factory = factory;
        this.supplier = supplier;
        this.names = new HashSet<>(Arrays.asList(names));
    }
    
    public DataField create(String name)
    {
        return factory.apply(name);
    }
    
    public static Fields byName(String name)
    {
        try
        {
            return valueOf(name.toUpperCase());
        }
        catch(IllegalArgumentException ex)
        {}
        
        for(Fields field : values())
        {
            if(field.names.contains(name))
                return field;
        }
        return null;
    }
}
