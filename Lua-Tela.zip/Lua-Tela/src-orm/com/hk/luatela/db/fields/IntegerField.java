package com.hk.luatela.db.fields;

import com.hk.json.JsonObject;
import com.hk.lua.Lua;
import com.hk.lua.LuaException;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaObject;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.hk.luatela.db.Instance;
import com.hk.luatela.db.Model;

public class IntegerField extends DataField
{
    private Long def;
    private boolean allowNull;
    
    public IntegerField(String name)
    {
        super(name);
    }
    
    public IntegerField(LuaInterpreter interp, LuaObject tbl)
    {
        super(interp, tbl);        
        LuaObject allowNull1 = tbl.isNil() ? Lua.nil() : tbl.getIndex(interp, "null");
        if(!allowNull1.isNil())
            allowNull = allowNull1.getBoolean();
        else
            allowNull = false;
        
        LuaObject def1 = tbl.isNil() ? Lua.nil() : tbl.getIndex(interp, "default");
        if(!def1.isNil())
            def = clean(def1).getInteger();
        else
            def = null;
    }

    @Override
    public void initiate(Model model, Instance ins)
    {
        if(def != null)
            ins.values.put(name, Lua.newNumber(def));
    }

    @Override
    public void appendCreate(Model model, StringBuilder sb)
    {
        sb.append('`');
        sb.append(name);
        sb.append("` INT");
        if(def != null)
            sb.append(" DEFAULT ").append(def);
        if(!allowNull)
            sb.append(" NOT NULL");
    }
    
    @Override
    public LuaObject clean(LuaObject obj) throws LuaException
    {
        if(obj.isInteger() || obj.isNil() && allowNull)
            return obj;
        else if(obj.isString())
            return Lua.newNumber(obj.getInteger());
        else
            throw new LuaException("expected integer" + (allowNull ? " or nil" : ""));
    }

    @Override
    public LuaObject toLuaObject(ResultSet set, int index) throws SQLException
    {
        return Lua.newNumber(set.getLong(index));
    }
    
    @Override
    public void toJavaObject(PreparedStatement stmt, int index, LuaObject value) throws SQLException
    {
        stmt.setLong(index, value.getInteger());
    }

    @Override
    public void exportToJson(JsonObject obj)
    {
        super.exportToJson(obj);
        obj.put("field", "int");
        obj.put("default", def);
        obj.put("allowNull", allowNull);
    }

    @Override
    public void importFromJson(JsonObject obj)
    {
        super.importFromJson(obj);
        def = obj.isNull("default") ? null : obj.getLong("default");
        allowNull = obj.getBoolean("allowNull");
    }
}
