package com.hk.luatela.db.fields;

import com.hk.json.JsonObject;
import com.hk.lua.Lua;
import com.hk.lua.LuaException;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaObject;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.hk.luatela.db.Instance;
import com.hk.luatela.db.Model;

public class StringField extends DataField
{
    private String def;
    private int length;
    private boolean allowNull;
    
    public StringField(String name)
    {
        super(name);
    }
    
    public StringField(LuaInterpreter interp, LuaObject tbl)
    {
        super(interp, tbl);        
        LuaObject length1 = tbl.isNil() ? Lua.nil() : tbl.getIndex(interp, "length");
        if(!length1.isNil())
        {
            if(!length1.isInteger() || length1.getInteger() < 0)
                throw new LuaException("expected 'length' to be a positive integer");
            if(length1.getInteger() > Integer.MAX_VALUE)
                throw new LuaException("expected 'length' to be a positive integer, below 2,147,483,648 (2^31)");
            
            length = (int) length1.getInteger();
        }
        else
            throw new LuaException("expected 'length' with string field");
        
        LuaObject allowNull1 = tbl.isNil() ? Lua.nil() : tbl.getIndex(interp, "null");
        if(!allowNull1.isNil())
            allowNull = allowNull1.getBoolean();
        else
            allowNull = false;
        
        LuaObject def1 = tbl.isNil() ? Lua.nil() : tbl.getIndex(interp, "default");
        if(!def1.isNil())
            def = clean(def1).getString();
        else
            def = null;
    }

    @Override
    public void initiate(Model model, Instance ins)
    {
        if(def != null)
            ins.values.put(name, Lua.newString(def));
    }
    
    @Override
    public void appendCreate(Model model, StringBuilder sb)
    {
        sb.append('`');
        sb.append(name);
        sb.append("` VARCHAR(");
        sb.append(length);
        sb.append(')');
        if(def != null)
            sb.append(" DEFAULT ").append('\'').append(escape(def)).append('\'');
        if(!allowNull)
            sb.append(" NOT NULL");
    }
    
    @Override
    public LuaObject clean(LuaObject obj) throws LuaException
    {
        if(obj.isString() || obj.isNil() && allowNull)
            return obj;
        else if(obj.isNumber())
            return Lua.newString(obj.getString());
        else
            throw new LuaException("expected string" + (allowNull ? " or nil" : ""));
    }

    @Override
    public LuaObject toLuaObject(ResultSet set, int index) throws SQLException
    {
        return Lua.newString(set.getString(index));
    }
    
    @Override
    public void toJavaObject(PreparedStatement stmt, int index, LuaObject value) throws SQLException
    {
        stmt.setString(index, value.getString());
    }

    @Override
    public void exportToJson(JsonObject obj)
    {
        super.exportToJson(obj);
        obj.put("field", "string");
        obj.put("default", def);
        obj.put("length", length);
        obj.put("allowNull", allowNull);
    }

    @Override
    public void importFromJson(JsonObject obj)
    {
        super.importFromJson(obj);
        def = obj.isNull("default") ? null : obj.getString("default");
        length = obj.getInt("length");
        allowNull = obj.getBoolean("allowNull");
    }
    
    private static final HashMap<String,String> sqlTokens;
    private static final Pattern sqlTokenPattern;

    static
    {           
        //MySQL escape sequences: http://dev.mysql.com/doc/refman/5.1/en/string-syntax.html
        String[][] search_regex_replacement = new String[][]
        {
                    //search string     search regex        sql replacement regex
                {   "\u0000"    ,       "\\x00"     ,       "\\\\0"     },
                {   "'"         ,       "'"         ,       "\\\\'"     },
                {   "\""        ,       "\""        ,       "\\\\\""    },
                {   "\b"        ,       "\\x08"     ,       "\\\\b"     },
                {   "\n"        ,       "\\n"       ,       "\\\\n"     },
                {   "\r"        ,       "\\r"       ,       "\\\\r"     },
                {   "\t"        ,       "\\t"       ,       "\\\\t"     },
                {   "\u001A"    ,       "\\x1A"     ,       "\\\\Z"     },
                {   "\\"        ,       "\\\\"      ,       "\\\\\\\\"  }
        };

        sqlTokens = new HashMap<>();
        String patternStr = "";
        for (String[] srr : search_regex_replacement)
        {
            sqlTokens.put(srr[0], srr[2]);
            patternStr += (patternStr.isEmpty() ? "" : "|") + srr[1];            
        }
        sqlTokenPattern = Pattern.compile('(' + patternStr + ')');
    }


    public static String escape(String s)
    {
        Matcher matcher = sqlTokenPattern.matcher(s);
        StringBuffer sb = new StringBuffer();
        while(matcher.find())
        {
            matcher.appendReplacement(sb, sqlTokens.get(matcher.group(1)));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }
}
