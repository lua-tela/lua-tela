package com.hk.luatela.db.fields;

import com.hk.json.JsonObject;
import com.hk.lua.Lua;
import com.hk.lua.LuaException;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaObject;
import com.hk.lua.LuaUserdata;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.hk.luatela.db.Instance;
import com.hk.luatela.db.Model;

public abstract class DataField extends LuaUserdata
{
    public String name;
    private boolean primary = false;
    
    public DataField(String name)
    {
        this.name = name;
    }
    
    public DataField(LuaInterpreter interp, LuaObject tbl)
    {
        LuaObject primary1 = tbl.isNil() ? Lua.nil() : tbl.getIndex(interp, "primary");
        if(!primary1.isNil())
        {
            if(!primary1.isBoolean())
                throw new LuaException("expected 'primary' to be a boolean");

            primary = primary1.getBoolean();
        }
    }
    
    public abstract void initiate(Model model, Instance ins);
    
    public abstract void appendCreate(Model model, StringBuilder sb);
    
    public abstract LuaObject toLuaObject(ResultSet set, int index) throws SQLException;

    public abstract void toJavaObject(PreparedStatement stmt, int index, LuaObject value) throws SQLException;
    
    public abstract LuaObject clean(LuaObject obj) throws LuaException;

    public void exportToJson(JsonObject obj)
    {
//        obj.put("name", name);
        obj.put("primary", primary);
    }

    public void importFromJson(JsonObject obj)
    {
//        if(obj.isNull("name"))
//            throw new RuntimeException("NO NAME?");
//        else
//            name = obj.getString("name");
        
        primary = !obj.isNull("primary") && obj.getBoolean("primary");
    }
    
    public DataField setPrimary()
    {
        primary = true;
        return this;
    }
    
    public boolean isPrimary()
    {
        return primary;
    }

    public boolean isAuto()
    {
        return false;
    }
    
    public void appendName(Model model, StringBuilder sb, boolean strict)
    {
        if(strict)
        {
            sb.append('`');
            sb.append(model.tblName);
            sb.append("`.");
        }
        sb.append('`');
        sb.append(name);
        sb.append('`');
    }

    @Override
    public String name()
    {
        return "FIELD*";
    }

    @Override
    public Object getUserdata()
    {
        return this;
    }
    
    @Override
    public String getString(LuaInterpreter interp)
    {
        return "field '" + name + "'";
    }
}
