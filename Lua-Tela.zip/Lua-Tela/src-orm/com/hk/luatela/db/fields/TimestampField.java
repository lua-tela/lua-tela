package com.hk.luatela.db.fields;

import com.hk.json.JsonNull;
import com.hk.json.JsonObject;
import com.hk.lua.Lua;
import com.hk.lua.LuaException;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaObject;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import com.hk.luatela.db.Instance;
import com.hk.luatela.db.Model;

public class TimestampField extends DataField
{
    private Object def;
    private boolean allowNull;
    
    public TimestampField(String name)
    {
        super(name);
    }
    
    public TimestampField(LuaInterpreter interp, LuaObject tbl)
    {
        super(interp, tbl);        
        LuaObject allowNull1 = tbl.isNil() ? Lua.nil() : tbl.getIndex(interp, "null");
        if(!allowNull1.isNil())
            allowNull = allowNull1.getBoolean();
        else
            allowNull = false;
        
        LuaObject def1 = tbl.isNil() ? Lua.nil() : tbl.getIndex(interp, "default");
        if(def1.isString() && def1.getString().equals("now"))
            def = "now";
        else if(!def1.isNil())
            def = clean(def1).getInteger();
        else
            def = null;
    }

    @Override
    public void initiate(Model model, Instance ins)
    {
        if(def != null)
            ins.values.put(name, Lua.newNumber(def.equals("now") ? System.currentTimeMillis() : (long) def));
    }

    @Override
    public void appendCreate(Model model, StringBuilder sb)
    {
        sb.append('`');
        sb.append(name);
        sb.append("` TIMESTAMP");
        if(def != null)
        {
            if(def.equals("now"))
                sb.append(" DEFAULT CURRENT_TIMESTAMP");
            else
                sb.append(" DEFAULT FROM_UNIXTIME(").append((long) def / 1000).append(')');
        }
        if(!allowNull)
            sb.append(" NOT NULL");
    }
    
    @Override
    public LuaObject clean(LuaObject obj) throws LuaException
    {
        if(obj.isInteger() || obj.isNil() && allowNull)
            return obj;
        else if(obj.isString() && obj.getString().equals("now"))
            return Lua.newNumber(System.currentTimeMillis());
        else
            throw new LuaException("expected millis as integer" + (allowNull ? " or nil" : ""));
    }

    @Override
    public LuaObject toLuaObject(ResultSet set, int index) throws SQLException
    {        
        return Lua.newNumber(set.getTimestamp(index).getTime());
    }
    
    @Override
    public void toJavaObject(PreparedStatement stmt, int index, LuaObject value) throws SQLException
    {
        stmt.setTimestamp(index, new Timestamp(value.getInteger()));
    }

    @Override
    public void exportToJson(JsonObject obj)
    {
        super.exportToJson(obj);
        obj.put("field", "timestamp");
        if(def == null)
            obj.put("def", JsonNull.NULL);
        else if(def.equals("now"))
            obj.put("def", "now");
        else
            obj.put("def", (long) def);
        obj.put("allowNull", allowNull);
    }

    @Override
    public void importFromJson(JsonObject obj)
    {
        super.importFromJson(obj);
        if(obj.isNull("default"))
            def = Lua.nil();
        allowNull = obj.getBoolean("allowNull");
    }
}
