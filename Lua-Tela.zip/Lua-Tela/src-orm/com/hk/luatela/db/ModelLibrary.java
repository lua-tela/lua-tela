package com.hk.luatela.db;

import com.hk.func.BiConsumer;
import com.hk.func.BiFunction;
import com.hk.lua.Environment;
import com.hk.lua.Lua;
import com.hk.lua.Lua.LuaMethod;
import com.hk.lua.LuaException;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaObject;
import com.hk.lua.LuaType;
import java.util.HashMap;
import java.util.Map;
import com.hk.luatela.db.fields.BooleanField;
import com.hk.luatela.db.fields.DataField;
import com.hk.luatela.db.fields.FloatField;
import com.hk.luatela.db.fields.IDField;
import com.hk.luatela.db.fields.IntegerField;
import com.hk.luatela.db.Model;
import com.hk.luatela.db.fields.Fields;
import com.hk.luatela.db.fields.StringField;
import com.hk.luatela.db.fields.TimestampField;

public enum ModelLibrary implements BiConsumer<Environment, LuaObject>, LuaMethod
{
    model() {
        @Override
        public LuaObject call(LuaInterpreter interp, LuaObject[] args0)
        {
            Lua.checkArgs(toString(), args0, LuaType.STRING);
            final String name = args0[0].getString();
            return Lua.newFunc((LuaInterpreter interp2, LuaObject[] args) -> {
                Lua.checkArgs(toString() + " '" + name + "'", args, LuaType.TABLE);
                Models models = interp2.getExtra("models", Models.class);
                Model mdl = models.getModel(Models.LUA, name);
                if(mdl == null)
                    mdl = models.addModel(new Model(interp2, Models.LUA, name, args[0]));
                return mdl;
            });
        }
    },
    field() {
        @Override
        public LuaObject call(LuaInterpreter interp, LuaObject[] args)
        {
            Lua.checkArgs(toString(), args, LuaType.STRING);
            String name = args[0].getString();
            LuaObject func = fields.get(name.toLowerCase());
            if(func == null)
                throw new LuaException("Unknown field data type '" + name + "'");
            return func;
        }
    };
    
    @Override
    public LuaObject call(LuaInterpreter interp, LuaObject[] args)
    {
        throw new Error();
    }
    
    @Override
    public void accept(Environment env, LuaObject table)
    {
        String name = toString();
        if(name != null && !name.trim().isEmpty())
            table.setIndex(env.interp, name, Lua.newFunc(this));
    }
    
    private static LuaObject fieldFunc(String name, BiFunction<LuaInterpreter, LuaObject, DataField> supp)
    {
        return Lua.newFunc((LuaInterpreter interp, LuaObject[] args) -> {
            Lua.checkArgs("field '" + name + "'", args, LuaType.TABLE);
            return supp.apply(interp, args[0]);
        });
    }
    
    private static final Map<String, LuaObject> fields = new HashMap<>();
    static
    {
        for(Fields field : Fields.values())
        {
            LuaObject f = null;
            
            for(String name : field.names)
            {
                if(f == null)
                    f = fieldFunc(name, field.supplier);
                
                fields.put(name, f);
            }
        }
    }
}
