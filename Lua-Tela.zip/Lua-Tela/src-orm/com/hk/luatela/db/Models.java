package com.hk.luatela.db;

import com.hk.json.JsonObject;
import com.hk.json.JsonValue;
import com.hk.lua.Lua;
import com.hk.lua.LuaInterpreter;
import com.hk.lua.LuaLibrary;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import com.hk.luatela.db.fields.DataField;

public final class Models
{
    private final File patches;
    private final Map<String, Model> namedModels;
    
    public Models(File patches)
    {
        this.patches = patches;
        namedModels = new HashMap<>();
    }

    public void importPatch(LuaInterpreter interp, LuaBase db, JsonValue val)
    {
        if(!val.isObject())
            throw new IllegalStateException("patch file isn't JSON object?");
        
        JsonObject obj = val.getObject();
        
        for(Map.Entry<String, JsonValue> ent : obj)
        {
            val = ent.getValue();
            Model mdl = new Model(interp, db, LuaBase.LUA, ent.getKey(), val.getObject());
            
            namedModels.put(ent.getKey(), mdl);
        }
        
//        throw new Error(); // TO BE CONTINUED...
    }
    
    public JsonObject toPatch(File models) throws FileNotFoundException
    {
        LuaInterpreter interp = Lua.reader(models);
        
        interp.importLib(LuaLibrary.BASIC);
        interp.importLib(LuaLibrary.COROUTINE);
        interp.importLib(LuaLibrary.STRING);
        interp.importLib(LuaLibrary.TABLE);
        interp.importLib(LuaLibrary.MATH);
        interp.importLib(LuaLibrary.IO);
        interp.importLib(LuaLibrary.OS);
        interp.importLib(LuaLibrary.JSON);
        interp.importLib(LuaLibrary.HASH);
        interp.importLib(new LuaLibrary<>(null, ModelLibrary.class));

        interp.setExtra("models", this);
        
        namedModels.clear();
        
        interp.execute();
        
        return exportJson();
    }
    
    public JsonObject exportJson()
    {
        JsonObject mdls = new JsonObject();
        
        for(Map.Entry<String, Model> ent : namedModels.entrySet())
        {
            JsonObject mdl = new JsonObject();
            Model model = ent.getValue();
            
            for(DataField field : model.fields)
            {
                JsonObject o = new JsonObject();
                field.exportToJson(o);
                mdl.put(field.name, o);
            }
            
            mdls.put(ent.getKey(), mdl);
        }
        
        return mdls;
    }

    public Model addModel(Model model)
    {
        return namedModels.put(model.name, model);
    }
    
    public Model getModel(int owner, String name)
    {
        return namedModels.get(name(owner) + "_" + name);
    }
    
    public Collection<Model> getModels()
    {
        return namedModels.values();
    }
    
    static String name(int code)
    {
        switch(code)
        {
            case LUA: return "lua";
            case SYS: return "sys";
            default: throw new IllegalArgumentException("only expected LUA or SYS, not " + code + ".");
        }
    }
    
    public static final int LUA = 1;
    public static final int SYS = 2;
}
